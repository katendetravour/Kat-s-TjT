## Queen_Anita-V3
   <a><img src='https://files.catbox.moe/wgzij3.jpg'/></a><a><img src='https://files.catbox.moe/wgzij3.jpg'/></a>
<p align="center"> 
<u>⚡ A simple WhatsApp User Bot Created Kats TjT ⚡</u>
</p>
<p align="center">
<img src="https://files.catbox.moe/wgzij3.jpg"/>       
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+•★⃝ QUEEN-+ANITA-+V3★⃝•;MULTI-DEVICE+WHATSAPP+BOT;DEVELOPED+BY+DAVID+CYRIL;RELEASED+DATE+22%2F8%2F2024." alt="Typing SVG" /></a>
 </p>
<p align="center">
<a href="#"><img title="Creator" src="https://files.catbox.moe/wgzij3.jpg"></a>
</p>
<p align="center">
<a href="https://github.com/DeeCeeXxx/Queen_Anita-V3/stargazers/"><img title="Stars" src="https://files.catbox.moe/wgzij3.jpg"></a>
<a href="https://github.com/DeeCeeXxx/Queen_Anita-V3/network/members"><img title="Forks" src=".https://files.catbox.moe/wgzij3.jpg"></a>
<a href="https://github.com/DeeCeeXxx/Queen_Anita-V3/watchers"><img title="Watching" src="https://files.catbox.moe/1sfsjt.jpg"></a>
<a href="https://github.com/DeeCeeXxx/Queen_Anita-V3/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-Yes-red.svg"></a>&nbsp;&nbsp;
</p>
<a><img src='.https://files.catbox.moe/wgzij3.jpg'/></a><a><img src='https://files.catbox.moe/wgzij3.jpg'/></a>
#

## Queen_Anita-V3 Deployment Methods
---
1.  **Fork Repo First, [`CLICK HERE`](https://github.com/DeeCeeXxx/Queen_Anita-V3/fork) (A MUST) and `Star ⭐ Repository` for Courage.**
2.  **Get `SESSION ID` ON [`REPLIT`](https://replit.com/@deeceexxx01/DavidCyril-X-pair-1)** 

3. **UPLOAD YOUR CREDS.JSON FILE ON SESSION FOLDER**

4. **Deploy on [`SCALINGO`](https://dashboard.scalingo.com)**

5. **Deploy on [`HEROKU`](https://dashboard.heroku.com/new?template*=https://github.com/DeeCeeXxx/Queen_Anita-V3)** 

6. **Deploy on [`REPLIT`](https://replit.com/github/Deeceexxx/Queen_Anita-V2)** 

7. **Deploy on [`RAILWAY`](https://railway.com/github/Deeceexxx/Queen_Anita-V2)**  

8. **You can visit Bot whatsapp channel [`BY CLICKING HERE`](https://whatsapp.com/channel/0029VaeRru3ADTOEKPCPom0L) for more**

9. **All Tutorials Here [`Click Here`](https://www.youtube.com/@DavidCyril_TECH)**

</a><a><img src='https://files.catbox.moe/1sfsjt.jpg'/></a>

## ```Connect With Me```<img src="https://github.com/0xAbdulKhalid/0xAbdulKhalid/raw/main/assets/mdImages/handshake.gif" width ="80"></h1> 
 <br> 
<p align="center">
<a href="https://wa.me/256744293759"><img src="https://files.catbox.moe/1sfsjt.jpg" />
<a href="https://wa.me/qr/XXEMFJ4LOVCEL1"><img src="https://files.catbox.moe/wgzij3.jpg" />
<a href="https://github.com/katendetravour/Kat-s-TjT.git"><img src="https://files.catbox.moe/1sfsjt.jpg" /><br>
<p align="center">
<img alt="Development" width="256" src="https://media2.giphy.com/media/W9tBvzTXkQopi/giphy.gif?cid=6c09b952xu6syi1fyqfyc04wcfk0qvqe8fd7sop136zxfjyn&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g" /> </p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
# 

<br>
<a><img src='https://files.catbox.moe/1sfsjt.jpg'/></a><a><img src='https://files.catbox.moe/1sfsjt.jpg'/></a>

* [🧑‍💻 Follow Queen_Anita-V3 Whatsapp Channel🧑‍💻](https://whatsapp.com/channel/0029VaeRru3ADTOEKPCPom0L)

* [🧑‍💻 Join Queen_Anita-V3 Telegram Group 🧑‍💻](https://t.me/dctech)

* [✅ Join Public Group ⚡](https://chat.whatsapp.com/KLu7a2r4bc4JFV8s5epvsF)

  <a><img src='https://files.catbox.moe/1sfsjt.jpg'/></a><a><img src='https://files.catbox.moe/1sfsjt.jpg'/></a>
  

- *Queen_Anita-V3 is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use Queen_Anita-V3 at your own risk by keeping this warning in mind.*
  
  #### ```KATS TJT  PROFILE VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/DeeCeeXxx/count.svg)

<a><img src='.https://files.catbox.moe/wgzij3.jpg'/></a><a><img src='https://files.catbox.moe/wgzij3.jpg'/></a>

## Community and Support

FOLLOW DAVID CYRIL WHAtSAPP CHANNEL FOR MORE UPDATES
[![JOIN WHATSAPP GROUP](https://wa.me/qr/XXEMFJ4LOVCEL1)](https://wa.me/qr/J3W6V6ICN5M2K1))
